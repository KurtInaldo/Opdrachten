<?php

$getal = 1;
for ($i = 1; $i <= 12; $i++) {
$prod = $i * $getal;
echo "$getal * $i = $prod" . PHP_EOL . PHP_EOL;
}

$getal = 2;
for ($i = 2; $i <= 12; $i++) {
$prod = $i * $getal;
echo "$getal * $i = $prod" . PHP_EOL . PHP_EOL;
}

$getal = 3;
for ($i = 3; $i <= 12; $i++) {
$prod = $i * $getal;
echo "$getal * $i = $prod" . PHP_EOL . PHP_EOL;
}

$getal = 4;
for ($i = 4; $i <= 12; $i++) {
$prod = $i * $getal;
echo "$getal * $i = $prod" . PHP_EOL . PHP_EOL;
}

$getal = 5;
for ($i = 5; $i <= 12; $i++) {
$prod = $i * $getal;
echo "$getal * $i = $prod" . PHP_EOL . PHP_EOL;
}

$getal = 6;
for ($i = 6; $i <= 12; $i++) {
$prod = $i * $getal;
echo "$getal * $i = $prod" . PHP_EOL . PHP_EOL;
}

$getal = 7;
for ($i = 7; $i <= 12; $i++) {
$prod = $i * $getal;
echo "$getal * $i = $prod" . PHP_EOL . PHP_EOL;
}

$getal = 8;
for ($i = 8; $i <= 12; $i++) {
$prod = $i * $getal;
echo "$getal * $i = $prod" . PHP_EOL . PHP_EOL;
}

$getal = 9;
for ($i = 9; $i <= 12; $i++) {
$prod = $i * $getal;
echo "$getal * $i = $prod" . PHP_EOL . PHP_EOL;
}

$getal = 10;
for ($i = 10; $i <= 12; $i++) {
$prod = $i * $getal;
echo "$getal * $i = $prod" . PHP_EOL . PHP_EOL;
}

$getal = 11;
for ($i = 11; $i <= 12; $i++) {
$prod = $i * $getal;
echo "$getal * $i = $prod" . PHP_EOL . PHP_EOL;
}

$getal = 12;
for ($i = 12; $i <= 12; $i++) {
$prod = $i * $getal;
echo "$getal * $i = $prod" . PHP_EOL . PHP_EOL;
}


?>